package com.app.updated;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpdatedDefectTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpdatedDefectTrackerApplication.class, args);
	}

}
